 var map;
 var markers = [];



 function initMap() 
 {
 		// Create a map object and specify the DOM element for display.
 		map = new google.maps.Map(document.getElementById("carte"), {
 		center: {lat: -34.397, lng: 150.644},
 		scrollwheel: false,
 		zoom: 5
 		// mapTypeId: google.maps.MapTypeId.ROADMAP
 	});
 	
 	 var params =
 	  {
 			  op : "listeToutPostits"
 	  };
 	  
 	  $.post("GestionPostItServlet", $.param(params), 
 			  function(response) 
 			  {
 		  			//
 		  			$.each(response, function(index, postit) 
 		  			{    // Iterate over the JSON array.
 		  				//alert(postit.id);
 		  				var latitude = parseFloat(postit.pointGeo.latitude);
 		  				var longitude = parseFloat(postit.pointGeo.longitude);
 		  				var latLng = new google.maps.LatLng(latitude, longitude);
 		  				var marker = new google.maps.Marker({
 		  				    position: latLng,
 		  				    map: map
 		  				  });
 		  				  map.panTo(latLng);
 		  				  map.setCenter(latLng);
 		  				  google.maps.event.addListener(marker, 'click', function()
 		  				  {
 		  					var url ="GestionPostItServlet?op=afPostIt&postit="+postit.id ;
 		  					window.location.href = url;
 		  					markers.push(marker);
 		  				  });
 		  				
 		  	        });
 			  }
 	  );
 }

function rechPostit() 
{	  
	  var inputAuteur;
	  var inputNinf;
	  var inputNsup;
	  var inputPerim;
	  var inputZone;
	  
	  inputAuteur = document.getElementById('auteur');
	  inputNinf = document.getElementById('noteinf');
	  inputNsup = document.getElementById('notesup');
	  inputPerim = document.getElementById('distance');
	  inputZone = document.getElementById('zone');
	  //alert(inputAuteur.value + ' ' + inputNsup.value + ' ' + inputNinf.value + ' ' + inputPerim.value + ' ' + inputZone.value);
	  
	  var geocoder = new google.maps.Geocoder();
	  geocoder.geocode({'address': inputZone.value}, function(results, status) {
		    if (status === google.maps.GeocoderStatus.OK) 
		    {
		      alert(results[0].geometry.location.lat());
		      var params =
		   	  {
		   			op : "rechPostIt",
		   			auteur : inputAuteur.value,
		   			notesup : inputNsup.value,
					noteinf : inputNinf.value,
					distance : inputPerim.value,
					zone : inputZone.value,
					longitude : results[0].geometry.location.lng(),
					latitude :results[0].geometry.location.lat()
		   	  };
		   	  
		   	  $.post("GestionPostItServlet", $.param(params), 
		   			  function(response) 
		   			  {
		   		  alert(response);
		   		  			$.each(response, function(index, postit) 
		   		  			{    // Iterate over the JSON array.
		   		  				//alert(postit.id);
		   		  				
		   		  				var latitude = parseFloat(postit.pointGeo.latitude);
		   		  				var longitude = parseFloat(postit.pointGeo.longitude);
		   		  			alert(latitude);
	   		  				alert(longitude);
		   		  				var latLng = new google.maps.LatLng(latitude, longitude);
		   		  				var marker = new google.maps.Marker({
		   		  				    position: latLng,
		   		  				    map: map
		   		  				  });
		   		  				marker.setIcon("/images/marker_blue.png");
		   		  				  map.panTo(latLng);
		   		  				  map.setCenter(latLng);
		   		  				  google.maps.event.addListener(marker, 'click', function()
		   		  				  {
		   		  					var url ="GestionPostItServlet?op=afPostIt&postit="+postit.id ;
		   		  					window.location.href = url;
		   		  					markers.push(marker);
		   		  				  });
		   		  				
		   		  	        });
		   			  }
		   	  );
		    } 
		    else 
		    {
		      alert('Geocode was not successful for the following reason: ' + status);
		    }
		  });
	  
	  
	  
}

function geocodeAddress(geocoder,address, resultsMap) {
	  geocoder.geocode({'address': address}, function(results, status) {
	    if (status === google.maps.GeocoderStatus.OK) {
	      resultsMap.setCenter(results[0].geometry.location);
	      var marker = new google.maps.Marker({
	        map: resultsMap,
	        icon: 'images/marker_blue.png',
	        position: results[0].geometry.location
	      });
	    } else {
	      alert('Geocode was not successful for the following reason: ' + status);
	    }
	  });
	}