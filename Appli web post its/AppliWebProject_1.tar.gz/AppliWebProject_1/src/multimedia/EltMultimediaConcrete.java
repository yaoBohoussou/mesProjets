package multimedia;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.Table;

@Entity
@Inheritance
@DiscriminatorColumn(name="elt_TYPE")
@Table(name="ElementMultimedia")
public class EltMultimediaConcrete implements EltMultimedia, Serializable
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	@Column(name="chemin")
	private String chemin;
	
	public EltMultimediaConcrete(){}
	
	public EltMultimediaConcrete(String chemin)
	{
		this.chemin = chemin;
	}

	public String getChemin() {
		return chemin;
	}

	public void setChemin(String chemin) {
		this.chemin = chemin;
	}
	
	public String toHtml() {
		return "<div><iframe width=\"280\" height=\"158\" src=\""+this.getChemin()+"\" frameborder=\"0\" allowfullscreen></iframe></div>";
	}
	
}
