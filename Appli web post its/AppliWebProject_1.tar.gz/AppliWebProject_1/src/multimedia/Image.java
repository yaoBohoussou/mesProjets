package multimedia;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("Image")
public class Image extends EltMultimediaConcrete
{
	public Image(){}
	
	public Image(String cheminImage) {
		super( cheminImage.trim());
		//Attention à la sécurité ici.
	}
	
	public String toHtml() {
		return "<div><img src=\""+this.getChemin()+"\" alt=\"image utilisateur\" style=\"max-width:400px;max-height:300px;\" /></div>";
	}
}