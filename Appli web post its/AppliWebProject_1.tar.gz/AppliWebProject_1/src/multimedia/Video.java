package multimedia;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/** C'est une vidéo Youtube ici */
@Entity
@DiscriminatorValue("Video")
public class Video extends EltMultimediaConcrete
{
	
	public Video(){}
	
	public Video(String cheminVideo) {
		super( cheminVideo.trim());
		//Attention à la sécurité ici.
	}
	
	public String toHtml() {
		return "<div><iframe width=\"280\" height=\"158\" src=\""+this.getChemin()+"\" frameborder=\"0\" allowfullscreen></iframe></div>";
	}
}