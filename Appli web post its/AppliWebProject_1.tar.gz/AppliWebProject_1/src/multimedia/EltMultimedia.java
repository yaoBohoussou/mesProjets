package multimedia;

public interface EltMultimedia
{
	String toHtml();
}
