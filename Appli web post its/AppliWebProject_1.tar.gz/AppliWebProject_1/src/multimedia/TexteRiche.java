package multimedia;

public class TexteRiche extends EltMultimediaConcrete
{
	public TexteRiche() {}
	
	public String toHtml() {
		return "------";
	}
}
