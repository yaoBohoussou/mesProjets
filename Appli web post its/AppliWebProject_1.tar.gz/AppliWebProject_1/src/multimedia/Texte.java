package multimedia;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("texte")
public class Texte extends EltMultimediaConcrete
{
	@Column(name="htmlTexte")
	private String htmlTexte;
	
	public Texte(){}
	public Texte(String texte) {
		this.htmlTexte = texte;
		//StringUtils.replaceEach(htmlTexte, new String[]{"&", "\"", "<", ">"}, new String[]{"&amp;", "&quot;", "&lt;", "&gt;"});
		this.htmlTexte = this.htmlTexte.replaceAll("\n+", "<br />");
		this.htmlTexte = this.htmlTexte.replaceAll("[\n\r]+", "<br />");
	}
	
	public String toHtml() {
		return "<p>" + htmlTexte + "</p>";
	}
	

	public String getHtmlTexte() {
		return htmlTexte;
	}
	public void setHtmlTexte(String htmlTexte) {
		this.htmlTexte = htmlTexte;
	}
}
