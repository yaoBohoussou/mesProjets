package utilisateur;

public interface Utilisateur
{
	void setPseudo(String pseudo);
	String getPseudo();
}
