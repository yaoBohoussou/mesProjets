package utilisateur;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import notable.Notable;

@Entity
@Table(name="Membre")
public class Membre extends Notable implements Utilisateur, Serializable
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	@Column(name="nom", nullable=false, length=30)
	private String nom;
	@Column(name="prenoms", nullable=false, length=30)
	private String prenoms;
	@Column(name="pseudo", nullable=false,unique=true, length=30)
	private String pseudo;
	@Column(name="password", nullable=false, length=30)
	private String password;
	@Column(name="avatarPath", nullable=true)
	private String avatarPath;
	
	public Membre()
	{
		this.avatarPath = "https://avatars1.githubusercontent.com/u/8598621?v=3&u=0eab29e9e712d19b60152d2e0f6393c5ff81066f&s=400";
	}
	
	public Membre(String pseudo) {
		super();
		this.pseudo = pseudo;
	}
	
	public void setPseudo(String pseudo) {
		this.pseudo = pseudo;
	}
	
	public String getPseudo() {
		return pseudo;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}
	
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public String getNom() {
		return nom;
	}
	
	public void setPrenoms(String prenoms) {
		this.prenoms = prenoms;
	}
	
	public String getPrenoms() {
		return prenoms;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setAvatarPath(String avatarPath) {
		this.avatarPath = avatarPath;
	}
	
	public String getAvatarPath() {
		return avatarPath;
	}
}
