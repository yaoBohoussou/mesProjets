package dao;

import java.util.List;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import utilisateur.Membre;
@Singleton
public class UtilisateurDao 
{
	@PersistenceContext(unitName="postItPU")
	private EntityManager em;
	
	
	public void ajouterMembre(Membre mb)
	{
		System.out.println("************"+mb.getPseudo()+"*******************");
		 em.persist(mb);
		 em.flush();
	}
	
	public Membre checkMembre(String pseudo, String mdp)
	{
		Membre mb = null;
		Query query = em.createQuery("FROM Membre where pseudo = :pseudo and password= :mdp");
		query.setParameter("pseudo", pseudo);
		query.setParameter("mdp", mdp);

        List lst = query.getResultList();
        if(!lst.isEmpty())
        	mb = (Membre)lst.get(0);
		
		return mb;
		
	} 
	
	public Membre getMembreByPseudo(String pseudo)
	{
		Membre mb = null;
		Query query = em.createQuery("FROM Membre where pseudo = :pseudo");
		query.setParameter("pseudo", pseudo);

        List lst = query.getResultList();
        if(!lst.isEmpty())
        	mb = (Membre)lst.get(0);
        
		return mb;
	}
	
	public void updateMembre(Membre mb)
	{
		em.merge(mb);	
	}
	
	
	public Boolean ifPseudoExist(String pseudo)
	{
		Boolean resultat= false;
		Query query = em.createQuery("FROM Membre where pseudo = :pseudo");
		query.setParameter("pseudo", pseudo);

        List lst = query.getResultList();
        if(!lst.isEmpty())
        	resultat = true;
		return resultat;
	}
}
