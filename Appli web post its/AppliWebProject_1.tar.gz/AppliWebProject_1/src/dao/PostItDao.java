package dao;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import postit.PostIt;
import postit.PostItInvite;
import postit.PostItMembre;
import utilisateur.Membre;

@Singleton
public class PostItDao 
{
	@PersistenceContext(unitName="postItPU")
	private EntityManager em;
	
	
	public void ajouterPostIt(PostIt postit) 
	{
		System.out.println("************"+postit.getTitre()+"*******************");
		if (postit instanceof PostItMembre)
		{
			System.out.println("************Membre*******************");
			PostItMembre p = (PostItMembre)postit;
			//em.merge(p.getAuteur());
			//em.flush();
		}
		if (postit instanceof PostItInvite)
		{
			System.out.println("************Utilisateur*******************");
			PostItInvite p = (PostItInvite)postit;
			em.persist(p.getAuteur());
			em.flush();
		}
		 em.persist(postit.getPointGeo());
		 em.persist(postit.getContenu());
		 em.persist(postit);
		 em.flush();
	}
	
	public List<PostIt> getListePostits() 
	{
		 Query query = em.createQuery("FROM PostIt");
		 List<PostIt> liste = (List<PostIt>) query.getResultList();
		/* for(PostIt pit : liste)
			 System.out.println(pit.getTitre());*/
		 return liste;
	}
	
	public PostIt getPostItById(Integer id) 
	{
		Query query = em.createQuery("FROM PostIt where id = :id");
		query.setParameter("id", id);
		List<PostIt> liste = (List<PostIt>) query.getResultList();
		if(!liste.isEmpty())
			return liste.get(0);
		else
			return null;
	}
}
