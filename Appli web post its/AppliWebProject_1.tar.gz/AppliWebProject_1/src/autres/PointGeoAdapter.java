package autres;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import postit.PointGeo;

public class PointGeoAdapter implements JsonSerializer<PointGeo>
{

	@Override
	public JsonElement serialize(PointGeo arg0, Type arg1, JsonSerializationContext arg2) 
	{
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty("longitude", arg0.getLongitude());
		jsonObject.addProperty("longitude", arg0.getLatitude());
		return jsonObject;
	}
	
}
