package autres;

import java.lang.reflect.Type;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import postit.PointGeo;
import postit.PostIt;

public class PostItAdapter implements JsonSerializer<PostIt>
{

	@Override
	public JsonElement serialize(PostIt arg0, Type arg1, JsonSerializationContext arg2) 
	{	
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty("id", arg0.getId());
		jsonObject.addProperty("titre", arg0.getTitre());
		
		GsonBuilder gsonBuilder = new GsonBuilder();
	    Gson gson = gsonBuilder.registerTypeAdapter(PointGeo.class, new PointGeoAdapter()).create();
		jsonObject.addProperty("pointGeo", gson.toJson(arg0.getPointGeo()));
		
		return jsonObject;
	}

}
