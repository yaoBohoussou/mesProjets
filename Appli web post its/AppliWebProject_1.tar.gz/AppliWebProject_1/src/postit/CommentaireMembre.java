package postit;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import utilisateur.Membre;

@Entity
@DiscriminatorValue("CommentaireMembre")
public class CommentaireMembre extends Commentaire
{
	@OneToOne//(fetch=FetchType.LAZY)
	@JoinColumn(name="membreId")
	private Membre auteur;
	
	public CommentaireMembre(){}

	public Membre getAuteur() {
		return auteur;
	}

	public void setAuteur(Membre auteur) {
		this.auteur = auteur;
	}
	
	
}
