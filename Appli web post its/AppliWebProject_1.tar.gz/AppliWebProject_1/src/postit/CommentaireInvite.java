package postit;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import utilisateur.Invite;

@Entity
@DiscriminatorValue("CommentaireInvite")
public class CommentaireInvite extends Commentaire
{
	@OneToOne//(fetch=FetchType.LAZY)
	@JoinColumn(name="inviteId")
	private Invite auteur;
	
	public CommentaireInvite(){}

	public Invite getAuteur() {
		return auteur;
	}

	public void setAuteur(Invite auteur) {
		this.auteur = auteur;
	}	
}
