package postit;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import utilisateur.Membre;
import utilisateur.Utilisateur;
@Entity
@DiscriminatorValue("PostItMembre")
public class PostItMembre extends PostIt
{
	@OneToOne//(fetch=FetchType.LAZY)
	@JoinColumn(name="membreId")
	private Membre auteur;
	
	public PostItMembre(){}
	
	public PostItMembre(Utilisateur auteur, String titre, Contenu contenu, PointGeo pointGeo)
	{
		super(titre,contenu,pointGeo);
	}

	public Membre getAuteur() {
		return auteur;
	}

	public void setAuteur(Membre auteur) {
		this.auteur = auteur;
	}
}
