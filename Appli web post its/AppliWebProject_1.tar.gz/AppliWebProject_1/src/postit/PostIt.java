package postit;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import notable.Notable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

import utilisateur.Invite;
import utilisateur.Membre;
import utilisateur.Utilisateur;

/** Un postit. */
/*
 * @OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ADDRESS_ID")
	protected Adresse adr;
 */
@Entity
@Inheritance
@DiscriminatorColumn(name="post_TYPE")
@Table(name="PostIt")
public class PostIt extends Notable implements Serializable
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	//@Transient
	//private Utilisateur auteur;
	
	@Column(name="titre", nullable=false, length=30)
	private String titre;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="contenuId")
	private Contenu contenu;

	@Transient
	private Date dateCreation;
	
	@Column(name="dateCreation", nullable=false, length=30)
	private String dateCrea;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="pointGeoId")
	private PointGeo pointGeo;
	
	@OneToMany (cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private List<Commentaire> commentaires;
	
	public PostIt(){}
	
	public PostIt(String titre, Contenu contenu, PointGeo pointGeo) 
	{
		super();
		//this.auteur = auteur;
		this.titre = titre;
		this.contenu = contenu;
		this.dateCreation = new Date();
		this.dateCrea = dateCreation.toString();
		this.pointGeo = pointGeo;
		this.commentaires = new ArrayList<Commentaire>();
	}
	
	public void ajouterCommentaire(Commentaire commentaire) {
		this.commentaires.add(commentaire);
	}
	
	public void supprimerCommentaire(int commentIx) {
		if (0 <= commentIx && commentIx < this.commentaires.size())
			this.commentaires.remove(commentIx);
	}
	
	public List<Commentaire> getCommentaires() {
		return this.commentaires;
	}
	
	public String getTitre() {
		return this.titre;
	}
	
	public Utilisateur getAuteur() {
		return new Membre();
	}
	
	public Contenu getContenu() {
		return this.contenu;
	}
	
	public Date getDateCreation() {
		Date dt = new Date();
		//dt.parse(dateCrea);
		dt = new Date(dateCrea);
		return dt ;
	}
	
	public PointGeo getPointGeo() {
		return this.pointGeo;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}

	/*public void setAuteur(Utilisateur auteur) {
		this.auteur = auteur;
	}*/

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public void setContenu(Contenu contenu) {
		this.contenu = contenu;
	}

	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
		setDateCrea(dateCreation.toString());
	}

	public void setPointGeo(PointGeo pointGeo) {
		this.pointGeo = pointGeo;
	}

	public void setCommentaires(List<Commentaire> commentaires) {
		this.commentaires = commentaires;
	}
	
	public String getDateCrea() {
		return dateCrea;
	}

	public void setDateCrea(String dateCrea) {
		this.dateCrea = dateCreation.toString();
	}

}