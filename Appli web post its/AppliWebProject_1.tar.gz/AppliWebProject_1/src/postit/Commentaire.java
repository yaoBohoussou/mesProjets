package postit;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import postit.Contenu;

import notable.Notable;

/** Un commentaire. */
@Entity
@Inheritance
@DiscriminatorColumn(name="com_TYPE")
@Table(name="Commentaire")
public class Commentaire extends Notable implements Serializable
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@OneToOne//(fetch=FetchType.LAZY)
	@JoinColumn(name="contenuId")
	private Contenu contenu;
	
	@Transient
	private Date dateCreation;
	
	@Column(name="dateCreation", nullable=false, length=30)
	private String dateCrea;
	
	
	public Commentaire(){}
	public Commentaire(Contenu contenu) {
		super();
		this.contenu = contenu;
		this.dateCreation = new Date();
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Contenu getContenu() {
		return contenu;
	}

	public void setContenu(Contenu contenu) {
		this.contenu = contenu;
	}

	public Date getDateCreation() {
		Date dt = new Date();
		dt.parse(dateCrea);
		return dt ;
	}

	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
		setDateCrea(dateCreation.toString());
	}
	
	public String getDateCrea() {
		return dateCrea;
	}


	public void setDateCrea(String dateCrea) 
	{
		this.dateCrea = dateCreation.toString();
	}


	
}
