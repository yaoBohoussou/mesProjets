package postit;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import java.io.Serializable;
import java.util.ArrayList;

import multimedia.EltMultimedia;
import multimedia.EltMultimediaConcrete;

@Entity
@Table(name="Contenu")
public class Contenu implements Serializable
{
	@Id
	@Column(name="contenuId")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	@OneToMany (cascade=CascadeType.ALL,fetch=FetchType.EAGER)//(mappedBy="owner")
	private List<EltMultimediaConcrete> contenu ;
	
	public Contenu()
	{
		contenu = new ArrayList<EltMultimediaConcrete>();
	}

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}



	public List<EltMultimediaConcrete> getContenu() {
		return contenu;
	}



	public void setContenu(List<EltMultimediaConcrete> contenu) {
		this.contenu = contenu;
	}



	public void addElement(EltMultimediaConcrete elt){
		this.contenu.add(elt);
	}
	
	public String toHtml() {
		String html = "<div>";
		for(EltMultimedia e : contenu){
			html+=e.toHtml();
		}
		
		html += "</div>";
		
		return html;
	}
	
	
}
