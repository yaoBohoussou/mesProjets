package postit;
import java.io.Serializable;
import java.lang.Math;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PointGeo")
public class PointGeo implements Serializable
{
	@Id
	@Column(name="pointGeoId")
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	private int id;
	@Column(name="latitude", nullable=false, length=30)
	private double latitude;
	@Column(name="longitude", nullable=false, length=30)
	private double longitude;
	
	
	public PointGeo(){}
	
	public PointGeo(double lat, double longitude) {
		this.latitude = lat;
		this.longitude = longitude;
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}


	public double getLatitude() {
		return latitude;
	}
	
	public double getLongitude() {
		return longitude;
	}

	static public double getDistance(PointGeo p, double latitude, double longitude){
	  // renvoi la distance en km
	  double lat_p = p.getLatitude();
	  double lon_p = p.getLongitude();
	  double rayon = 6371.0;
	  return rayon*Math.acos(Math.sin(lat_p)*Math.sin(latitude)+Math.cos(lat_p)*Math.cos(latitude)*Math.cos(lon_p-longitude));
	}


}